# d = {
#     'noida_visakhaptanam': [        ['Dankaur', 'Jewar', 'Morena', 'Gwalior', 'Jhansi', 'sagar', 'Lakhnadon', 'Balaghat', 'Jeypore'],
#         ['Dankaur', 'Jewar', 'Morena', 'Gwalior', 'Jhansi', 'sagar', 'Mandla', 'Nowrangpur', 'Araku Valley']
#     ],
#     'delhi_vizag': [        ['Agra', 'Gwalior', 'Jagdal Pur'],
#         ['Jhansi', 'Chhatarpur', 'Panna'],
#         ['Lalitpur', 'Lakhnadon', 'Bastar']
#     ],
#     'vizag_hyderabad': [        ['Rajamundry', 'Eluru', 'Suryapet'],
#         ['Annavaram', 'Koyyalgudam', 'Katangur']
#     ],
#     'hyderabad_bangalore': [        ['Shadnagar', 'Mahbubnagar', 'Anantapur', 'Bagepalli'],
#         ['Kurnool', 'Noonepalli', 'Mydukur', 'Kadapa']
#     ],
#     'chennai_mumbai': [        ['Gudur', 'Rapur', 'Cholapur'],
#         ['Nellore', 'Hyderabad', 'Pune']
#     ],
#     'vizag_kolkata': [        ['Srikakulam', 'cuttak', 'Alampur'],
#         ['Palasa', 'Deogarh', 'Kharaghpur']
#     ],
#     'delhi_jammu': [        ['Panipat', 'Dasuir', 'Vijaypur'],
#         ['Hansi', 'Batala', 'Sujanpur']
#     ],
#     'jaipur_haryana': [        ['Daunatpura', 'Beelapur', 'Shivpuri'],
#         ['Jaipur', 'Haryana', 'Shahpura', 'Mundhal', 'Sorkhi']
#     ],
#     'hyderabad_bangalore': [        ['Mahbubnagar', 'Kurnool', 'Anantapur', 'Bagepalli'],
#         ['Mahbubnagar', 'Kurnool', 'Nandyala', 'Kadapa']
#     ],
#     'hyderabad_mumbai': [        ['Miyapur', 'Solapur', 'Indapur', 'Pune'],
#         ['Chittapur', 'Kalaburagi', 'juer', 'Daund', 'Thane']
#     ]
# }


d = {
    'noida_visakhaptanam': [        ['Dankaur', 'Jewar', 'Morena', 'Gwalior', 'Jhansi', 'sagar', 'Lakhnadon', 'Balaghat', 'Jeypore'],
        ['Dankaur', 'Jewar', 'Morena', 'Gwalior', 'Jhansi', 'sagar', 'Mandla', 'Nowrangpur', 'Araku Valley']
    ],
    'delhi_vizag': [        ['Agra', 'Gwalior', 'Jagdal Pur'],
        ['Jhansi', 'Chhatarpur', 'Panna'],
        ['Lalitpur', 'Lakhnadon', 'Bastar']
    ]
}
# origin_destination = f"{origin}_{destination}"

# if origin_destination in d:
#     print("Route is clear!")
# else:
#     print("Alert: Route is not available.")

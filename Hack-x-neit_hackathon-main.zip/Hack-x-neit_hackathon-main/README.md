# Hack-x-neit_hackathon
PROBLEM STATEMENT NAME: “ Traffic Master: AI-Powered Traffic Prediction and Optimization for Smarter Commutes”
